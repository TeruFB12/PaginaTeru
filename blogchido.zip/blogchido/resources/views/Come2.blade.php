<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Vastayas</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="main">
  <div id="header">
    <div id="logo">
    <a href="https://www.facebook.com/terunotsuki.fullbuster/" >Teru Fullbuster Ruiz Juarez Jose Angel</a >
      
    </div>
    <div id="buttons">
      <ul>
        <li class="first"><a href="{{ route( 'Ionia' ) }}">Ionia</a></li>
        <li><a href=""></a></li>
        <li><a href="#">Parejas</a></li>
        <li><a href=""></a></li>
        <li><a href="https://signup.lan.leagueoflegends.com/es/signup/redownload">Juega League</a></li>
       
      </ul>
    </div>
  </div>
  <div id="content">
    <div id="right">
      <div id="sidebar">
        <ul>
          <li>
            <h2>Archivos</h2>
            <ul>
              <li><a href="{{ route( 'Ahri' ) }}">Ahri 2011-12-14</a> <i></i></li>
              <li><a href="{{ route( 'Xayah' ) }}">Xayah 2017-04-19</a> <i></i></li>
              <li><a href="{{ route( 'Rakan' ) }}">Rakan 2017-04-19</a> <i></i></li>
              <li><a href="{{ route( 'Sett' ) }}">Sett 2020-01-14</a> <i></i></li>
            </ul>
          </li>
          <li>
            <h2>Datos Curiosos </h2>
            <ul>
              <li><a href="#">Origenes</a></li>
              <li><a href="#">Vida actual</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
    <div id="left">
      <h1>¡La historia de los Vastaya!</h1></br> 
      <div>
        <p>Los vastaya son criaturas quiméricas de Runaterra cuyo linaje contiene tanto sangre humana como magia espiritual
        de una raza prehumana. Desde el feroz y bestial poder de Rengar a la seducción raposa de Ahri, los vastaya pueden 
        tener aspectos muy diferentes, pero todos comparten características animales y humanas. Se dice que los vastaya son 
        originarios de un rincón de Ionia al que un grupo de humanos huyeron tratando de escapar de la Gran Guerra del Vacío.<br />
          <br />
          Allí, estos refugiados entraron en contacto con una tribu de criaturas metamórficas que estaban profundamente ligadas a la magia natural del mundo.
          Estas criaturas espirituales, conocidas como vastayashai'rei, acogieron a los refugiados humanos y acabaron dando lugar a lo que la gente de Runaterra 
          llama vastaya: una clasificación que incluye a todo tipo de especies de criaturas quiméricas.<br />
          Con el tiempo, los diversos descendientes comenzaron a asentarse en distintas regiones y adoptaron, de forma natural, 
          diferentes aspectos (simios, aves, e incluso peces), según las criaturas que mejor representasen sus rasgos más fuertes.
          Además de por sus cambios de formas, los vastaya son conocidos por su extrema longevidad.<br />
          Se sabe que algunos de ellos han vivido durante miles de años, mientras que se dice que otros son inmortales.
          Con el paso del tiempo, y cuando la estirpe vastaya ya se había expandido por Runaterra, tuvo lugar una aberración 
          genética: algunos humanos con trazas de sangre vastaya adquirieron la habilidad de cambiar de forma.</p><br />
      </div>
      <div class="small">
        <p class="date">Diario de Campo de Teru Fullbuster 22/Enero/3750</p></br>
      <div>

        <h2>Mi conclusión y experiencia</h2></br>

        Pasé los meses siguientes explorando Ionia en busca de toda la información que pudiera recopilar 
        sobre las diversas especies de vastaya en un intento por crear una guía taxonómica que recogiese 
        toda la fauna de Runaterra. Aunque he acumulado una cantidad enorme de información sobre los vastaya,
        queda mucho por descubrir (sospecho que, al limitar mi investigación a Ionia, he descubierto solo una
        fracción de la gran diversidad aún por descubrir de esta clasificación). Aun así, por ahora, toca 
        seguir adelante. Acabo de abrir la puerta a la investigación sobre los vastaya, así que ahora tendrá 
        que ser otro cronista quien la continúe. En este momento, estoy centrando mi atención en las otras
        criaturas de Runaterra cuyas historias aún no han sido contadas: esas horripilantes armas vivientes
        conocidas como oscuros. Las criaturas corruptoras del Vacío. Esas criaturas ilusorias de leyenda, 
        los yordles. Esas historias no pueden seguir ocultas, y yo debo ser el explorador que las desvele 
        con sus palabras. De hecho, puede que sea el único capaz de hacerlo.</br>
        </div></br>
      <div class="small">
        <p class="date">Publicado el dia 22 de Enero del año 3755, ultima entrada del diario</p>
        
      </div>
    </div>
    <div class="padding">League of Legends es una marca registrada de Riot Games &copy;.</div>
  </div>
  <div id="footer">
    <p>Copyright &copy; 2020. Diseñado por <a href="https://www.facebook.com/terunotsuki.fullbuster/">Angel Ruiz Juarez</a></p>
    <p><a href="">Politica de Privacidad que me invente.</a> | <a href="">Terminos de uso que tambien me invente.</a></p>
  </div>
</div>
</body>
</html>
